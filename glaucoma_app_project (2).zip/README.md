# 👁️ Glaucoma Risk Analytics & Prediction App

An interactive Streamlit web application to analyze glaucoma clinical datasets, explore patient records, and estimate glaucoma risk using Machine Learning.

---

## 📌 Features

- **Dashboard Overview**: Key metrics, risk stage distribution, and clinical parameter charts (IOP, RNFL, CDR).
- **Patient Explorer**: Filterable tabular view for custom queries by age, gender, and risk stage.
- **Glaucoma Predictor**: Real-time Machine Learning model using Random Forest to assess risk based on diagnostic inputs.

---

## 🛠️ Project Structure

```text
├── cleaned_glaucoma_risk_dataset.csv   # Dataset
├── app.py                             # Streamlit Application Script
├── requirements.txt                   # Project Dependencies
└── README.md                          # Project Documentation
```

---

## 🚀 Getting Started

### 1. Prerequisites
Ensure Python 3.9+ is installed on your system.

### 2. Install Dependencies
```bash
pip install -r requirements.txt
```

### 3. Run the Streamlit App
Place `cleaned_glaucoma_risk_dataset.csv` in the same directory as `app.py` and execute:
```bash
streamlit run app.py
```
